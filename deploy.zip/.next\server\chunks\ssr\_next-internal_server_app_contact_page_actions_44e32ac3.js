module.exports=[15731,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_contact_page_actions_44e32ac3.js.map