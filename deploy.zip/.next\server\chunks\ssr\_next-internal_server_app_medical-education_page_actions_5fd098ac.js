module.exports=[68016,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_medical-education_page_actions_5fd098ac.js.map