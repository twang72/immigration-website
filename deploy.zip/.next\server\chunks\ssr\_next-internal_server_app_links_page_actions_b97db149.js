module.exports=[72276,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_links_page_actions_b97db149.js.map