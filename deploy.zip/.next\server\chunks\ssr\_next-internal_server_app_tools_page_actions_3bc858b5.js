module.exports=[85926,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_tools_page_actions_3bc858b5.js.map